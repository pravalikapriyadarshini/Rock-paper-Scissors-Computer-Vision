import random
import cv2
import cvzone
from cvzone.HandTrackingModule import HandDetector
import time

# ---------------- CAMERA ----------------
cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

# ---------------- HAND DETECTOR ----------------
detector = HandDetector(maxHands=1)

# ---------------- GAME VARIABLES ----------------
timer = 0
stateResult = False
startGame = False
scores = [0, 0]  # [AI, Player]

# ---------------- MAIN LOOP ----------------
while True:
    # Load background
    imgBG = cv2.imread("Resources/BG.png")
    imgBG = cv2.resize(imgBG, (1280, 720))   # IMPORTANT → prevent broadcast error

    success, img = cap.read()
    if not success:
        continue

    # ---------------- CAMERA PROCESSING ----------------
    img = cv2.flip(img, 1)                   # Mirror (selfie view)
    imgScaled = cv2.resize(img, (400, 400))  # Resize camera feed

    # ---------------- HAND DETECTION ----------------
    hands, imgScaled = detector.findHands(imgScaled, draw=True)

    # ---------------- GAME LOGIC ----------------
    if startGame:

        if not stateResult:
            timer = time.time() - initialTime
            cv2.putText(
                imgBG, str(int(timer)), (580, 430),
                cv2.FONT_HERSHEY_PLAIN, 5, (255, 0, 255), 4
            )

            if timer > 3:
                stateResult = True
                timer = 0

                if hands:
                    playerMove = None
                    fingers = detector.fingersUp(hands[0])

                    # Rock, Paper, Scissors logic
                    if fingers == [0, 0, 0, 0, 0]:
                        playerMove = 1  # Rock
                    elif fingers == [1, 1, 1, 1, 1]:
                        playerMove = 2  # Paper
                    elif fingers == [0, 1, 1, 0, 0]:
                        playerMove = 3  # Scissors

                    randomNumber = random.randint(1, 3)
                    imgAI = cv2.imread(f"Resources/{randomNumber}.png", cv2.IMREAD_UNCHANGED)

                    # Overlay AI image
                    imgBG = cvzone.overlayPNG(imgBG, imgAI, (100, 300))

                    # Decide winner
                    if (playerMove == 1 and randomNumber == 3) or \
                       (playerMove == 2 and randomNumber == 1) or \
                       (playerMove == 3 and randomNumber == 2):
                        scores[1] += 1

                    elif (playerMove == 3 and randomNumber == 1) or \
                         (playerMove == 1 and randomNumber == 2) or \
                         (playerMove == 2 and randomNumber == 3):
                        scores[0] += 1

    # ---------------- PLACE CAMERA ON BG ----------------
    imgBG[250:650, 800:1200] = imgScaled

    # Show AI move if result decided
    if stateResult:
        imgBG = cvzone.overlayPNG(imgBG, imgAI, (100, 300))

    # ---------------- SCORES ----------------
    cv2.putText(imgBG, str(scores[0]), (390, 200),
                cv2.FONT_HERSHEY_PLAIN, 4, (255, 255, 255), 6)
    cv2.putText(imgBG, str(scores[1]), (1120, 200),
                cv2.FONT_HERSHEY_PLAIN, 4, (255, 255, 255), 6)

    # ---------------- DISPLAY ----------------
    cv2.imshow("Rock Paper Scissors", imgBG)

    key = cv2.waitKey(1)
    if key == ord('s'):
        startGame = True
        initialTime = time.time()
        stateResult = False

    if key == ord('q'):
        break

# ---------------- CLEANUP ----------------
cap.release()
cv2.destroyAllWindows()